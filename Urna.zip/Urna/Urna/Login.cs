﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Urna
{
    public partial class Login : Form
    {
        
        public Login()
        {
            InitializeComponent();

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            txtdig1.Text += "3";
        }

        private void button14_Click(object sender, EventArgs e)
        {
            Form2 login = new Form2();
            login.Show();

            this.Hide();
        }

        private void Login_Load(object sender, EventArgs e)
        {
            
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            txtdig1.Text += "1";
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            txtdig1.Text += "2";
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            txtdig1.Text += "4";
        }

        private void btnConfirmar_Click(object sender, EventArgs e)
        {

            Resultado votos = new Resultado(txtdig1.Text);
            votos.Show();
            /*int candidato1 = 0;
            int candidato2 = 0;
            int candidato3 = 0;
            int candidato4 = 0;

            MessageBox.Show("Voto Confirmado");

            if (txtdig1.Text == "14")
            {
                candidato1 += 1;
            }
            if (txtdig1.Text == "15")
            {
                candidato2 += 1;
            }
            if (txtdig1.Text == "16")
            {
                candidato3 += 1;
            }
            if (txtdig1.Text == "17")
            {
                candidato4 += 1;
            }
            txtdig1.Text = "";
            this.picimagem1.Image = null;
            lblnome.Text = "";
            */
        }
        public Login(int resultado)
        {
            InitializeComponent();


        }

        private void btn5_Click(object sender, EventArgs e)
        {
            txtdig1.Text += "5";
        }

        private void btn6_Click(object sender, EventArgs e)
        {
            txtdig1.Text += "6";
        }

        private void btn7_Click(object sender, EventArgs e)
        {
            txtdig1.Text += "7";
        }

        private void btn8_Click(object sender, EventArgs e)
        {
            txtdig1.Text += "8";
        }

        private void btn9_Click(object sender, EventArgs e)
        {
            txtdig1.Text += "9";
        }

        private void btn0_Click(object sender, EventArgs e)
        {
            txtdig1.Text += "0";
        }

        private void ptbximagemcand_Click(object sender, EventArgs e)
        {
            
        }

        private void txtdig1_TextChanged(object sender, EventArgs e)
        {
            if (txtdig1.Text == "14")
            {
                picimagem1.Load("C:/Users/Bruno Ap Moura/Desktop/Projetos Pessoais/Urna/Imagemcadidato/Faustao.jpg");
                picimagem1.SizeMode = PictureBoxSizeMode.StretchImage;
                lblnome.Text = "Faustão";
            }
            if (txtdig1.Text == "15")
            {
                picimagem1.Load("C:/Users/Bruno Ap Moura/Desktop/Projetos Pessoais/Urna/Imagemcadidato/Silvio.jpg");
                picimagem1.SizeMode = PictureBoxSizeMode.StretchImage;
                lblnome.Text = "Silvio Santos";
            }
            if (txtdig1.Text == "16")
            {
                picimagem1.Load("C:/Users/Bruno Ap Moura/Desktop/Projetos Pessoais/Urna/Imagemcadidato/Tiririca.jpg");
                picimagem1.SizeMode = PictureBoxSizeMode.StretchImage;
                lblnome.Text = "Tiririca";
            }
            if (txtdig1.Text == "17")
            {
                picimagem1.Load("C:/Users/Bruno Ap Moura/Desktop/Projetos Pessoais/Urna/Imagemcadidato/Elon.jpg");
                picimagem1.SizeMode = PictureBoxSizeMode.StretchImage;
                lblnome.Text = "Elon Musk";
            }
        }

        private void btnAnular_Click(object sender, EventArgs e)
        {
            txtdig1.Text = "";
        }

        private void btnBranco_Click(object sender, EventArgs e)
        {
            int Votobranco = 0;
           Votobranco += 1;
        }
    }
}
