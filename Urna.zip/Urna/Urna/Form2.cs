﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Urna
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void btnvoltar_Click(object sender, EventArgs e)
        {
            Login Urna = new Login();
            Urna.Show();

            this.Hide();

        }

        private void btnEntrar_Click(object sender, EventArgs e)
        {
            if (txtUsuario.Text == "Bruno264227" && txtSenha.Text == "W218cpd004")
            {
                Resultado resultado = new Resultado();
                resultado.Show();

                this.Hide();
            }
            else
            {
                MessageBox.Show("Usuario ou Senha ADM inválida");
            }
        }
    }
}
